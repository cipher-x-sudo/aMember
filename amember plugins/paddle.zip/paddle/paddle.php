<?php
/**
 * Paddle Payments Standard
 * Contributed by R Woodgate, Cogmentis Ltd
 *
 * ============================================================================
 * Revision History:
 * ----------------
 * 2021-02-27   v1.5    R Woodgate  Sync invoice rebill date to Paddle
 * 2021-02-23   v1.4    R Woodgate  Record user country from receipt
 * 2021-02-13   v1.3    R Woodgate  Added receipt url
 * 2021-02-13   v1.2    R Woodgate  Added payment details update url
 * 2021-01-30   v1.1    R Woodgate  Added postback resending
 * 2021-01-20   v1.0    R Woodgate  Plugin Created
 * ============================================================================
 * @am_payment_api 6.0
 */
class Am_Paysystem_Paddle extends Am_Paysystem_Abstract
{
    const PLUGIN_STATUS = self::STATUS_PRODUCTION;
    const PLUGIN_REVISION = '6.3.9';
    
    protected $defaultTitle = 'Paddle';
    protected $defaultDescription = 'Payment via Paddle gateway';
    protected $_canAutoCreate = true;
    protected $_canResendPostback = true;
    
    const SUBSCRIPTION_ID = 'paddle_subscription_id';
    const PMT_RECEIPT_URL = 'paddle_receipt_url';
    const CARD_UPDATE_URL = 'paddle_update_url';
    const CATALOG_ID = 'paddle_prod_id';
    const API_URL_BASE = 'https://vendors.paddle.com/api/2.0';
    const PASSTHROUGH_INV = 'am_invoice';
    
    public function init(): void
    {
        $this->getDi()->billingPlanTable->customFields()->add(
            new Am_CustomFieldText(
                static::CATALOG_ID,
                'Paddle Subscription Plan ID',
                "Recurring billing plans *MUST* have a Paddle Subscription Plan with the SAME 'Second Period' and same default currency. Product IDs are optional for single payment billing plans, but if provided must have same default currency."
            )
        );
        $this->getDi()->blocks->add('thanks/success',
            new Am_Block_Base('Paddle Statement', 'paddle-statement', $this, [$this, 'renderStatement']));
    }
    
    public function renderStatement(Am_View $v)
    {
        if (isset($v->invoice) && $v->invoice->paysys_id == $this->getId()) {
            $msg = ___("This order was processed by our online reseller & Merchant of Record, Paddle.com, who also handle order related inquiries and returns. The payment will appear on your bank/card statement as:");
            return <<<CUT
<div class="am-block am-paddle-statement">
    <p>$msg <strong>PADDLE.NET*{$this->getConfig('statement_desc')}</strong></p>
</div>
CUT;
        }
    }
    
    public function onBeforeRender(Am_Event $e): void
    {
        // Inject Paddle Payment Update URL into detailed subscriptions widget
        if (strpos($e->getTemplateName(), 'blocks/member-history-detailedsubscriptions') !== false) {
            $v = $e->getView();
            foreach ($v->activeInvoices as & $invoice) {
                if ($invoice->paysys_id == $this->getId()) {
                    if ($_ = $invoice->data()->get(static::CARD_UPDATE_URL)) {
                        $invoice->_updateCcUrl = $_;
                    }
                }
            }
        }
        
        // Inject Paddle receipt link into payment history widget
        if (strpos($e->getTemplateName(), 'blocks/member-history-paymenttable') !== false) {
            $v = $e->getView();
            foreach ($v->payments as & $p) {
                if ($p->paysys_id == $this->getId()) {
                    if ($_ = $p->data()->get(static::PMT_RECEIPT_URL)) {
                        $p->_invoice_url = $_;
                    }
                }
            }
        }
    }
    
    public function allowPartialRefunds()
    {
        // Payments *can* be partially refunded via Paddle, but we can't allow
        // that via aMember because Paddle subscription payments can be made in
        // customer's local currency, which may be different to the aMember
        // invoice currency
        return false;
    }
    
    public function getRecurringType()
    {
        return self::REPORTS_REBILL;
    }
    
    public function getSupportedCurrencies()
    {
        return [
            'USD',
            'EUR',
            'GBP',
            'ARS',
            'AUD',
            'CAD',
            'CHF',
            'CZK',
            'DKK',
            'HKD',
            'HUF',
            'INR',
            'ILS',
            'JPY',
            'KRW',
            'MXN',
            'NOK',
            'NZD',
            'PLN',
            'RUB',
            'SEK',
            'SGD',
            'THB',
            'TRY',
            'TWD',
            'UAH'
        ];
    }
    
    public function isNotAcceptableForInvoice(Invoice $invoice)
    {
        // For recurring invoices, check at least one of the recurring items
        // has a plan set up in Paddle that we can base the recurring paylink on
        if ($invoice->rebill_times >= 1 && !$this->getPaddlePlan($invoice)) {
            return 'Paddle subscription plans are not configured';
        }
        return parent::isNotAcceptableForInvoice($invoice);
    }
    
    public function _initSetupForm(Am_Form_Setup $form): void
    {
        $form->addInteger('vendor_id', ['size' => 8])
            ->setLabel("Vendor ID\n" . "From the Developer Tools > Authentication menu of your Paddle Dashboard.")
            ->addRule('required');
        
        $form->addSecretText('vendor_auth_code', ['class' => 'am-el-wide'])
            ->setLabel("Auth Code\n" . "Use your default API key or generate a new one from the Developer Tools > Authentication menu of your Paddle Dashboard.")
            ->addRule('required');
        
        $form->addTextarea('public_key', ['class' => 'am-el-wide', 'rows' => 14])
            ->setLabel("Public Key\n" . "From the Developer Tools > Public Key menu of your Paddle Dashboard. Include the <em>-----BEGIN PUBLIC KEY-----</em> and <em>-----END PUBLIC KEY-----</em> lines.")
            ->addRule('required');
        
        $fs = $this->getExtraSettingsFieldSet($form);
        $fs->addAdvCheckbox('hrt_lock')->setLabel('Lock User Account on Fraud Warning
        You need to configure Paddle to send "High Risk Transaction Created" and "High Risk Transaction Updated" webhook alerts. If checked, will add a note and lock the user account until the flagged transaction is approved.');
        $fs->addAdvCheckbox('show_grid')->setLabel(___("Show Plans in Product Grid\nIf checked, the plugin will add a column to the Manage Products grid"));
        $fs->addText('image_url', [
            'class' => 'el-wide',
            'placeholder' => 'https://www.example.com/path/to/my_logo.png'
        ])->setLabel("Default Image URL\nAn absolute URL to a square image of your brand or product. Recommended minimum size is 128x128px. Supported image types are: .gif, .jpeg, and .png. Will be used for single payments where the optional Paddle Product ID is not supplied.");
        $fs->addText('statement_desc')->setLabel("Statement Description\nThe Statement Description from your Paddle Dashboard > Checkout > Checkout Settings page. Shown on the thanks page to help alert customer as to what will appear on their card statement.");
    }
    
    public function isConfigured()
    {
        return $this->getConfig('vendor_id')
            && $this->getConfig('vendor_auth_code')
            && $this->getConfig('public_key');
    }
    
    public function getPaddlePlan(Invoice $invoice)
    {
        // Finds first suitable Paddle Subscription Plan/Product ID
        // Recurring invoices require a subscription plan
        // Single payment invoices can use a product or nothing (custom)
        foreach ($invoice->getItems() as $item) {
            /* @var $item InvoiceItem */
            // Recurring invoices require a Subscription Plan
            if ($invoice->rebill_times >= 1 && !$item->rebill_times) {
                continue;
            }
            // Single payment invoices should use a Product only
            if (!$invoice->rebill_times && $item->rebill_times >= 1) {
                continue;
            }
            if ($plan_id = $item->getBillingPlanData(static::CATALOG_ID)) {
                return $plan_id;
            }
        }
        return null;
    }
    
    public function _process($invoice, $request, $result): void
    {
        // Paddle lets us customise the checkout parameters for a product or
        // subscription using the Generate Paylink API. This means we can
        // repurpose products / subscription plans as required to allow more
        // complex checkouts like multi-item carts, coupon discounts etc. See:
        // https://developer.paddle.com/api-reference/product-api/pay-links/createpaylink
        
        //* Recurring invoices require a Paddle Plan for their rebills
        $product_id = $this->getPaddlePlan($invoice);
        if (!$product_id && $invoice->rebill_times >= 1) {
            throw new Am_Exception_InternalError('No Paddle Subscription Plan ID found');
        }
        
        //* If recurring invoice has a different first period than second
        //* period, we need to handle it as a number-of-days trial in Paddle
        $trial_days = 0;
        if ($invoice->first_period != $invoice->second_period
            && $invoice->rebill_times >= 1
        ) {
            $rebill_date = new DateTime($invoice->calculateRebillDate(1));
            $trial_days = $rebill_date->diff(new DateTime('now'))->days + 1;
        }
        
        //* Prepare log
        $log = $this->getDi()->invoiceLogRecord;
        $log->title = 'PAYLINK';
        $log->user_id = $invoice->user_id;
        $log->invoice_id = $invoice->pk();
        
        //* Prepare paylink params
        $params = [
            'product_id' => $product_id,
            'title' => $invoice->getLineDescription(),
            // 'webhook_url'        => 'string',    // handled below (custom products)
            'prices[0]' => strtoupper($invoice->currency) . ':' . $invoice->first_total,
            'recurring_prices[0]' => strtoupper($invoice->currency) . ':' . $invoice->second_total,
            'trial_days' => $trial_days,
            'custom_message' => $invoice->getTerms(),
            // 'coupon_code'        => 'string',    // aMember uses its own coupons
            'discountable' => 0,           // so don't display coupon field.
            // 'image_url'          => 'string',    // handled below (custom products)
            'return_url' => $this->getReturnUrl(),
            'quantity_variable' => 0,
            'quantity' => 1,
            'expires' => gmdate('Y-m-d', strtotime('tomorrow')),
            // 'affiliates'         => 'string',    // possible future enhancement? :)
            // 'recurring_affiliate_limit' => 123,  // possible future enhancement? :)
            'marketing_consent' => 0,
            'customer_email' => $invoice->getEmail(),
            'customer_country' => $invoice->getCountry(),
            'customer_postcode' => $invoice->getZip(),
            'passthrough' => json_encode([static::PASSTHROUGH_INV => $invoice->public_id]),
            // 'vat_number'         => 'string',    // These are for convenience
            // 'vat_company_name'   => 'string',    // only, and if used, must
            // 'vat_street'         => 'string',    // *all* be pre-filled, but
            // 'vat_city'           => 'string',    // as we can't guarantee
            // 'vat_state'          => 'string',    // the checkout will have
            // 'vat_country'        => 'string',    // them all, it's best to
            // 'vat_postcode'       => 'string'     // leave them all out
        ];
        
        //* Handle single payment invoices where a product ID was not found
        //* These show as "Custom" product transactions in Paddle
        if (!$product_id && !$invoice->rebill_times) {
            unset(
                $params['product_id'],
                $params['recurring_prices[0]'],
                $params['trial_days']
            );
            $params['webhook_url'] = $this->getPluginUrl('ipn');
            
            // Add default image if available and correctly formatted
            $image_url = $this->getConfig('image_url');
            if (parse_url($image_url, PHP_URL_SCHEME) != '') {
                $params['image_url'] = $image_url;
            }
        }
        
        //* Generate the custom pay link
        $response = $this->_sendRequest('/product/generate_pay_link', $params, $log);
        
        //* Decode and check paylink
        $resp_data = @json_decode($response->getBody(), true);
        if (empty($resp_data)) {
            throw new Am_Exception_InternalError("Empty response from paddle");
        }
        if (!$resp_data['success'] || empty($resp_data['response']['url'])) {
            throw new Am_Exception_InternalError("Could not get paylink");
        }
        
        //* Open pay page
        $a = new Am_Paysystem_Action_HtmlTemplate_Paddle($this->getDir(), "paddle.phtml");
        $a->invoice = $invoice;
        $a->button_msg = ___('Proceed to Checkout');
        $a->taxind_msg = ___('Converted prices include VAT');
        $a->conversion_msg = sprintf(
            '%1$s (<span id="paddle_currency">%2$s</span> %3$s)',
            ___('Invoice Summary'),
            $invoice->currency,
            ___('Conversion')
        );
        $a->vendor = (int)$this->getConfig('vendor_id');
        $a->paylink = $resp_data['response']['url'];
        $result->setAction($a);
    }
    
    public function createTransaction($request, $response, array $invokeArgs)
    {
        return new Am_Paysystem_Paddle_Transaction($this, $request, $response, $invokeArgs);
    }
    
    public function cancelAction(Invoice $invoice, $actionName, Am_Paysystem_Result $result)
    {
        // Get subscription
        $subscription_id = $invoice->data()->get(static::SUBSCRIPTION_ID);
        if ($subscription_id) {
            
            //* Prepare log
            $log = $this->getDi()->invoiceLogRecord;
            $log->title = 'CANCEL';
            $log->user_id = $invoice->user_id;
            $log->invoice_id = $invoice->pk();
            
            //* Make request
            $response = $this->_sendRequest(
                '/subscription/users_cancel',
                ['subscription_id' => $subscription_id],
                $log
            );
            $resp_data = @json_decode($response->getBody(), true);
            if (!$resp_data['success']) {
                $result->setFailed('Cancellation request failed: ' . $resp_data['error']['message']);
                return $result;
            }
            $result->setSuccess();
        }
    }
    
    public function processRefund(InvoicePayment $payment, Am_Paysystem_Result $result, $amount)
    {
        // Paddle refunds are not instantaneous - they get requested via API
        // and approved by Paddle staff, at which point a webhook alert is issued
        
        //* Prepare log
        $log = $this->getDi()->invoiceLogRecord;
        $invoice = $payment->getInvoice();
        $log->title = 'REFUND';
        $log->user_id = $invoice->user_id;
        $log->invoice_id = $invoice->pk();
        
        //* Make request
        $response = $this->_sendRequest(
            '/payment/refund',
            [
                'order_id' => $payment->transaction_id,
                // 'amount'   => $amount,
                'reason' => 'Refund requested by user (' . $payment->getUser()->login . ')',
            ],
            $log
        );
        $resp_data = @json_decode($response->getBody(), true);
        if (!$resp_data['success']) {
            $result->setFailed('Refund request failed: ' . $resp_data['error']['message']);
            return $result;
        }
        
        $result->setSuccess();
        // We will not add refund record here because it will be handled by
        // IPN script once the refund is approved and processed by Paddle.
    }
    
    /**
     * Private convenience method to send authenticated Paddle API requests
     */
    private function _sendRequest(
        $url,
        ?array $params = null,
        ?InvoiceLog $log = null,
        $method = Am_HttpRequest::METHOD_POST
    ): HTTP_Request2_Response {
        $request = $this->createHttpRequest();
        $request->setUrl(static::API_URL_BASE . $url);
        $request->setMethod($method);
        $request->setHeader([
            'Content-Type' => 'application/x-www-form-urlencoded'
        ]);
        
        // Add authentication
        $request->addPostParameter([
            'vendor_id' => $this->getConfig('vendor_id'),
            'vendor_auth_code' => $this->getConfig('vendor_auth_code')
        ]);
        
        // Add params and send
        if (!is_null($params)) {
            $request->addPostParameter($params);
        }
        $response = $request->send();
        
        // Log it?
        if ($log) {
            $log->mask($this->getConfig('vendor_id'), '***VENDOR_ID***');
            $log->mask($this->getConfig('vendor_auth_code'), '***VENDOR_AUTH_CODE***');
            $log->paysys_id = $this->getId();
            $log->add($request);
            $log->add($response);
        }
        
        // Return response
        return $response;
    }
    
    /**
     * Show Paddle plans on the Manage Products grid
     */
    public function onGridProductInitGrid(Am_Event_Grid $event): void
    {
        if (!$this->getConfig('show_grid')) {
            return;
        }
        $grid = $event->getGrid();
        $grid->addField(new Am_Grid_Field(static::CATALOG_ID, ___('Paddle ID'), false, 'right'))
            ->setRenderFunction(function (Product $product)
            {
                $ret = [];
                foreach ($product->getBillingPlans() as $plan) {
                    $data = $plan->data()->get(static::CATALOG_ID);
                    $ret[] = ($data) ? $data : '&ndash;';
                }
                $ret = implode('<br />', $ret);
                return '<td style="text-align:right">' . $ret . '</td>';
            });
    }
}

class Am_Paysystem_Paddle_Transaction extends Am_Paysystem_Transaction_Incoming
{
    protected $_autoCreateMap = [
        'name' => 'customer_name',
        'email' => 'email',
        'country' => 'country',
        'user_external_id' => 'email',
        'invoice_external_id' => 'order_id',
    ];
    
    public function findInvoiceId()
    {
        // Try decoding to get PASSTHROUGH_INV field
        $ret = json_decode($this->request->getPost('passthrough'), true);
        if (!empty($ret[Am_Paysystem_Paddle::PASSTHROUGH_INV])) {
            return $ret[Am_Paysystem_Paddle::PASSTHROUGH_INV];
        }
        // Could be a legacy invoice, so return it all
        return $this->request->getPost('passthrough');
    }
    
    public function autoCreateGetProducts()
    {
        // Could be a subscription plan or product ID
        $item_name = get_first(
            $this->request->getPost('subscription_plan_id'),
            $this->request->getPost('product_id')
        );
        if (empty($item_name)) {
            return;
        }
        $billing_plan = $this->getPlugin()->getDi()->billingPlanTable->findFirstByData(
            Am_Paysystem_Paddle::CATALOG_ID,
            $item_name
        );
        if ($billing_plan) {
            return [$billing_plan->getProduct()];
        }
    }
    
    public function getUniqId()
    {
        return $this->request->getPost('order_id')   // Payments / Refunds
            ?? $this->request->getPost('alert_id');  // Other alerts
    }
    
    public function validateSource()
    {
        $fields = $this->request->getPost();
        $public_key = $this->plugin->getConfig('public_key');
        $signature = base64_decode($fields['p_signature']);
        
        unset($fields['p_signature']);
        ksort($fields);
        foreach ($fields as $k => $v) {
            if (!in_array(gettype($v), ['object', 'array'])) {
                $fields[$k] = "$v";
            }
        }
        $data = serialize($fields);
        return openssl_verify($data, $signature, $public_key, OPENSSL_ALGO_SHA1);
    }
    
    public function validateStatus()
    {
        return true;
    }
    
    public function validateTerms()
    {
        return true;
    }
    
    public function processValidated(): void
    {
        //* Save subscription ID if set
        $subscription_id = $this->request->getPost('subscription_id');
        if (!empty($subscription_id)) {
            $this->invoice->data()->set(
                Am_Paysystem_Paddle::SUBSCRIPTION_ID,
                $subscription_id
            )->update();
        }
        
        //* Save payment details update URL if set
        //* NB: Set globally as it has changed any time update_url is set ;-)
        $update_url = $this->request->getPost('update_url');
        if (!empty($update_url)) {
            $this->invoice->data()->set(
                Am_Paysystem_Paddle::CARD_UPDATE_URL,
                $update_url
            )->update();
        }
        
        //* Handle webhook alerts
        switch ($this->request->getPost('alert_name')) {
            
            case 'subscription_created':
                // nothing to do here as subscription_payment_succeeded
                // fires for free subscriptions too
                break;
            
            case 'subscription_updated':
                if ('active' == $this->request->getPost('status')) {
                    $this->invoice->setStatus(Invoice::RECURRING_ACTIVE); // self-checks
                }
                // Update rebill date if this was changed in Paddle subscription
                // NB: Does not change access periods, because we don't know
                // why the date was changed - so leave it to be done manually
                $paddle_rebill_date = $this->request->getPost('next_bill_date');
                if ($this->invoice->rebill_date != $paddle_rebill_date) {
                    $this->invoice->updateQuick('rebill_date', $paddle_rebill_date);
                }
                break;
            
            case 'subscription_cancelled':
                $this->invoice->setCancelled(true);
                break;
            
            case 'subscription_payment_succeeded':
            case 'payment_succeeded':
                
                // Update user country if needed
                $user = $this->invoice->getUser();
                $country = $this->request->getPost('country');
                if ($user && $country && $user->country != $country) {
                    $user->updateQuick('country', $country);
                }
                
                // Add payment / access
                if ((float)$this->invoice->first_total == 0
                    && $this->invoice->status == Invoice::PENDING
                ) {
                    $this->invoice->addAccessPeriod($this);
                } else {
                    $p = $this->invoice->addPayment($this);
                    $receipt_url = $this->request->getPost('receipt_url');
                    if (!empty($receipt_url)) {
                        $p->data()->set( // Save the receipt url
                            Am_Paysystem_Paddle::PMT_RECEIPT_URL,
                            $receipt_url
                        )->update();
                    }
                }
                
                // We are all done for one-off payments...
                if ('payment_succeeded' == $this->request->getPost('alert_name')) {
                    break;
                }
                
                // Paddle subscriptions continue indefinitely, so we need to
                // cancel it once all expected payments have been made
                $payment_count = $this->request->getPost('instalments');
                $expected = $this->invoice->getExpectedPaymentsCount();
                if ($subscription_id && $payment_count >= $expected) {
                    $this->log->add(
                        "All $expected payments made for subscription_id: $subscription_id"
                    );
                    $result = new Am_Paysystem_Result();
                    $result->setSuccess();
                    $this->getPlugin()->cancelAction($this->invoice, 'cancel', $result);
                    if ($result->isFailure()) {
                        $this->log->add("Unable to cancel subscription_id: $subscription_id - " . $result->getLastError());
                    }
                }
                break;
            
            case 'subscription_payment_refunded':
            case 'payment_refunded':
                // NB: we can't use the amount as Paddle currency localisation
                // means refunds may be in a different currency to invoice
                $this->invoice->addRefund(
                    $this,
                    $this->getUniqId()//,
                //$this->request->getParam('amount')
                );
                break;
            
            case 'payment_dispute_created':
                $this->invoice->addChargeback(
                    $this,
                    $this->getUniqId()
                );
                break;
            
            case 'high_risk_transaction_created':
            case 'high_risk_transaction_updated':
                $email = $this->request->getPost('customer_email_address');
                $user = $this->getPlugin()->getDi()->userTable->findFirstByEmail($email);
                if ($user && $this->getPlugin()->getConfig('hrt_lock')) {
                    // Log this warning as a user note
                    $note = $this->getPlugin()->getDi()->userNoteRecord;
                    $note->user_id = $user->user_id;
                    $note->dattm = $this->getPlugin()->getDi()->sqlDateTime;
                    
                    // Lock account until case is resolved
                    $lock = true;
                    $note->content = ___('Paddle flagged a recent payment by this user as high risk (%s chance of fraud). User account disabled.',
                        (float)$this->request->getPost('risk_score') . '%');
                    if ('rejected' == $this->request->getPost('status')) {
                        $lock = true;
                        $note->content = ___('Paddle rejected the high risk payment. User account disabled.');
                    }
                    // Case resolved ok - unlock account
                    if ('accepted' == $this->request->getPost('status')) {
                        $lock = false;
                        $note->content = ___('Paddle approved the high risk payment. User account reenabled.');
                    }
                    $note->insert();
                    $user->lock($lock);
                }
                break;
        }
    }
}

// Allows core templates to be overridden with plugin specific files if needed
class Am_Paysystem_Action_HtmlTemplate_Paddle extends Am_Paysystem_Action_HtmlTemplate
{
    protected $_template;
    protected $_path;
    
    public function __construct($path, $template)
    {
        $this->_template = $template;
        $this->_path = $path;
    }
    
    public function process(Am_Mvc_Controller $action = null): void
    {
        $action->view->addScriptPath($this->_path);
        
        $action->view->assign($this->getVars());
        $action->renderScript($this->_template);
        
        throw new Am_Exception_Redirect;
    }
}